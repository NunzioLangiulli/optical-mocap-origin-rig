---
name: Geometry or documentation issue
about: Report a reproducible defect or unclear instruction
title: "[Issue] "
labels: ""
assignees: ""
---

- Revision, file and model hash:
- Expected behaviour:
- Observed behaviour:
- Steps to reproduce:
- Slicer/build environment, if applicable:
- Evidence (screenshot, measurement or log):
- Was this observed digitally, on a physical print, or in Nexus?

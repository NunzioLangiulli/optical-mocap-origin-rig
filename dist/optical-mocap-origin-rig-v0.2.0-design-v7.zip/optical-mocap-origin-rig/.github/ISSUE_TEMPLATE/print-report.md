---
name: Print or physical validation report
about: Share reproducible print, measurement or Nexus evidence
title: "[Print report] "
labels: ""
assignees: ""
---

## Configuration

- Design revision and STL SHA-256:
- Printer/nozzle/plate:
- Filament, colour, batch and drying:
- Slicer version and settings:
- Orientation, brim and supports:

## Outcome

- Coupon or complete rig:
- Print result and photographs:
- Thread engagement / tripod plate fit:
- Measurements, method and uncertainty:
- Marker type, centring and visibility:
- Nexus version and observed result, if tested:

## Limitations

State which steps were not tested. Remove printer credentials and unrelated personal/laboratory data before attaching files.
